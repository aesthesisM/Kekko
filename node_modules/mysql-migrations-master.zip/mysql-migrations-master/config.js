module.exports = {
  'table' : 'mysql_migrations_347ertt3e',
  'migrations_types' : ['up', 'down']
};
